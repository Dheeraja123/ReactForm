import React, { Fragment } from 'react';
import { Link } from 'react-router-dom';
import { connect } from 'react-redux';
import { userActions } from '../_actions';

class EditPage extends React.Component {
    constructor(props) {
        super(props);;
        this.state = {
            user: {
                firstName: '',
                number: '',
                email: '',
                username: '',
                id: '',
                password: ''
            },
            saveInfo: false
        };
        this.handleChange = this.handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);

    }

    componentDidMount() {
        this.props.getUsers();
    }

    componentWillReceiveProps() {
        if (this.props.users) {
            {
                this.props.users && this.props.users.items && this.props.users.items.map((user, index) =>
                    this.setState({
                        user: {
                            firstName: user.firstName,
                            number: user.number,
                            email: user.email,
                            username: user.username,
                            id: user.id,
                            password: user.password
                        }
                    })
                )
            }
        }
    }

    handleChange(e) {
        var name = e.target.name;
        var value = e.target.value;
        const { user } = this.state;
        this.setState({
            user: {
                ...user,
                [name]: value
            }
        });
    }

    handleSubmit(event) {
        event.preventDefault();
        this.setState({ saveInfo: true });
        const { user } = this.state;
        if (user.firstName && user.number && user.email && user.username) {
            this.props.saveUser(user);
        }
    }

    render() {
        const { user } = this.state;
        const { users } = this.props;

        return (
            <div className="col-md-6 col-md-offset-3">
                <h2>Save Details</h2>
                {users && users.items && users.items.map((user, index) =>
                    <Fragment>
                        <div>
                            <label htmlFor="firstName"> Name</label>
                            <input type="text" className="form-control" name="firstName" defaultValue={user.firstName} onChange={this.handleChange} />
                        </div>
                        <div>
                            <label htmlFor="number">Phone Number</label>
                            <input type="number" className="form-control" name="number" defaultValue={user.number} onChange={this.handleChange} />
                        </div>
                        <div>
                            <label htmlFor="email">Email</label>
                            <input type="email" className="form-control" name="email" defaultValue={user.email} onChange={this.handleChange} />
                        </div>

                        <div>
                            <label htmlFor="username">Username</label>
                            <input type="text" className="form-control" name="username" defaultValue={user.username} onChange={this.handleChange} />
                        </div>
                    </Fragment>
                )}
                <br />
                <div className="form-group">
                    {
                        this.state.saveInfo ?
                            <button className="btn btn-primary" onClick={this.handleSubmit} >Saving...</button>
                            :
                            <button className="btn btn-primary" onClick={this.handleSubmit} >SAVE</button>
                    }
                    <span></span>
                    <Link to="/" className="btn btn-link">Home</Link>
                </div>

            </div>


        );

    }
}

function mapState(state) {
    const { users, authentication } = state;
    const { user } = authentication;
    return { user, users };
}

const actionCreators = {
    getUsers: userActions.getAll,
    saveUser: userActions.saveDetails

}

const connectedEditPage = connect(mapState, actionCreators)(EditPage);
export { connectedEditPage as EditPage };